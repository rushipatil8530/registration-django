# urls.py

from django.urls import path
from .views import registration_form

urlpatterns = [
    path('', registration_form, name='registration_form'),
    # Add other URL patterns as needed
]
