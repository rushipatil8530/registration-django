# views.py
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_protect
from .models import Registration

@csrf_protect
def registration_form(request):
    if request.method == 'POST':
        partnerType = request.POST.get('partnerType')
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        pan = request.POST.get('pan')
        pincode = request.POST.get('pincode')
        kyc = request.POST.get('kyc')
        password = request.POST.get('password')
        confirmPassword = request.POST.get('confirmPassword')

        # Validate and save data to the database
        if partnerType and name and email and phone and pan and pincode and kyc and password and confirmPassword:
            registration = Registration(
                partnerType=partnerType,
                name=name,
                email=email,
                phone=phone,
                pan=pan,
                pincode=pincode,
                kyc=kyc,
                password=password,
                confirmPassword=confirmPassword
            )
            registration.save()
            return redirect('success_page')  # Redirect to a success page or wherever you want

    return render(request, 'registration_form.html')
