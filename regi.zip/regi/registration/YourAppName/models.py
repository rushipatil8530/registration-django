from django.db import models

class Registration(models.Model):
    PARTNER_CHOICES = [
        ('', 'Partner Type'),
        ('bank1', 'Bank 1'),
        ('bank2', 'Bank 2'),
        ('bank3', 'Bank 3'),
    ]

    KYC_CHOICES = [
        ('pan', 'PAN'),
        ('companyPan', 'Company PAN'),
    ]

    partnerType = models.CharField(max_length=20, choices=PARTNER_CHOICES)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    pan = models.CharField(max_length=10)
    pincode = models.CharField(max_length=10)
    kyc = models.CharField(max_length=20, choices=KYC_CHOICES)
    myfile = models.FileField(upload_to='kyc_documents/')
    password = models.CharField(max_length=50)
    confirmPassword = models.CharField(max_length=50)

    def __str__(self):
        return self.name
