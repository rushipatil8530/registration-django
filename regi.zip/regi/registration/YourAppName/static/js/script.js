function submitForm() {
    var response = grecaptcha.getResponse();
    console.log("reCAPTCHA Response:", response);
}

    // Reset any previous error messages
    document.getElementById("errorMessage").innerText = "";

    // Fetch form values
    var partnerType = document.getElementById("partnerType").value;
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var pan = document.getElementById("pan").value;
    var pincode = document.getElementById("pincode").value;
    var kyc = document.getElementById("kyc").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    // Validate other form fields as needed

    // Perform form submission or other actions
    // Example: Send data to a server using AJAX or redirect the user

    // For demonstration purposes, let's log the form data to the console
    console.log("Form Data:");
    console.log("Partner Type: " + partnerType);
    console.log("Name: " + name);
    console.log("Email: " + email);
    console.log("Phone: " + phone);
    console.log("PAN: " + pan);
    console.log("PIN Code: " + pincode);
    console.log("KYC: " + kyc);
    console.log("Password: " + password);
    console.log("Confirm Password: " + confirmPassword);

    // Reset the form (optional)
    document.getElementById("registrationForm").reset();


